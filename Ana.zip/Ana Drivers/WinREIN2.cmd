@echo off
setlocal enabledelayedexpansion
set "LogPath=C:\RST_Log.log"

for /f "tokens=1,2 delims=," %%A in ('powershell -nologo -command ^
    "Get-Partition | Where-Object { $_.Type -eq 'Recovery' } | ForEach-Object { Write-Output ($_.DiskNumber.ToString() + ',' + $_.PartitionNumber.ToString()) }"') do (

    set "diskNumber=%%A"
    set "partitionNumber=%%B"
    
    echo %date%%Time% Processing Recovery partition: Disk %%A, Partition %%B
    echo select disk %%A > diskpart.txt
    echo select partition %%B >> diskpart.txt
    echo assign letter=X >> diskpart.txt
    diskpart /s diskpart.txt > nul
    attrib -A -S -H -I X:\Recovery\WindowsRE\winre.wim 2>nul
    

    if exist "X:\Recovery\WindowsRE\winre.wim" (
        echo    Found winre.wim in partition Disk %%A, Partition %%B
        set "wimPath=X:\Recovery\WindowsRE\winre.wim"
        goto :mountWIM   
    )
    echo remove letter=X > diskpart_cleanup.txt
    diskpart /s diskpart_cleanup.txt > nul 2>nul
)

if not defined diskNumber (
    echo WinRE partition not found.
    goto :eof
)
goto :eof


:mountWIM
set mountPath=C:\ProgramData\Dell\UpdatePackage\Mount
if not exist "%mountPath%" (
    mkdir "%mountPath%"
)
dism /Mount-Wim /WimFile:"%wimPath%" /index:1 /MountDir:"%mountPath%"

Echo %date%%Time% "Successfully Mount the WinRE.wim"
set "driverFolder=%~dp0Drivers"
if not exist "%driverFolder%" (
    echo %date%%Time%[INFO] Driver folder not found: %driverFolder%
    goto :unmount
)

echo [INFO] Adding drivers from %driverFolder%
dism /Image:"%mountPath%" /Add-Driver /Driver:"%driverFolder%" /Recurse /forceunsigned 
if errorlevel 1 (
    echo [INFO] Did not add drivers.
    goto :unmount
)

:unmount
echo [INFO] Unmounting and saving changes...
dism /Unmount-Wim /MountDir:"%mountPath%" /Commit
if exist "%mountPath%" (
    rmdir "%mountPath%"
)
attrib +A +S +H +I X:\Recovery\WindowsRE\winre.wim

(
    echo select disk %diskNumber%
    echo select partition %partitionNumber%
    echo remove letter=X
) > diskpart.txt

diskpart /s diskpart.txt > nul
del diskpart.txt
if exist diskpart_cleanup.txt del diskpart_cleanup.txt
echo Done.


exit /b